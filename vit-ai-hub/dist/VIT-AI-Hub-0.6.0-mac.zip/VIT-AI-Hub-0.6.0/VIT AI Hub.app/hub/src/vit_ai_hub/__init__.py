"""VIT AI Hub: lokale GUI + privacy gateway voor lokaal/Claude/GPT/Cursor/OpenRouter/OmniRoute."""

__version__ = "0.6.0"